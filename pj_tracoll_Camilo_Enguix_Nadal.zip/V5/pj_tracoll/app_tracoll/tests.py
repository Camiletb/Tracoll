from django.test import TestCase

# Create your tests here.
from django.test import TestCase
from django.contrib.auth.models import User

class LoginLogoutTestCase(TestCase):
    
    def setUp(self):
        self.user = User.objects.create_user(
            username='testuser', password='testpass')
        self.client.login(username='testuser', password='testpass')

    def test_login(self):
        # Ensure the login page returns a successful response
        response = self.client.get('/login/')
        self.assertEqual(response.status_code, 200)

        # Ensure the user can log in
        response = self.client.post('/login/', {'username': 'testuser', 'password': 'testpass'})
        self.assertEqual(response.status_code, 302)

    def test_logout(self):
        # Ensure the user can log out
        response = self.client.get('/logout/')
        self.assertEqual(response.status_code, 302)